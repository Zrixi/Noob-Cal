import java.util.Scanner;

class setBoi {

	public long setBoi(long fa) {

		return fa;
	}

}

public class Cal {

	public static void main(String[] args) {
		// Property of ZrixiStudios
		// Java by Zrixi
		// Batch By Pringle

		String Version = "1.3.0";

		Scanner b = new Scanner(System.in);

		System.out.println("Enter a Number");

		long ans1 = b.nextLong();

		System.out.println("Enter a Second Number");

		long ans2 = b.nextLong();

		long fans = ans1 + ans2;

		System.out.println("Final Result \n" + fans);

		setBoi f = new setBoi();

		fans = f.setBoi(fans);

		System.out.println("Do you want to Add on Final? [Y/N]");

		Scanner text = new Scanner(System.in);

		String ask = text.nextLine();

		switch (ask) {
		case "Y":

			System.out.println("Enter Your next Number");

			long ans3 = b.nextLong();

			System.out.printf("Final result \n");
			System.out.println(fans + ans3);
			break;

		case "N":

			System.out.println(" ");
			break;

		}
		System.out.println(" ");

	}

}
